// Tous les textes du site, en français et en anglais.
// Pour ajouter une langue (ex : kinyarwanda "rw"), copie le bloc "en" et traduis.
export const LANGS = ["fr", "en"] as const;
export type Lang = (typeof LANGS)[number];

export const dict = {
  fr: {
    heroTitle: "Crée des vidéos avec l'IA",
    heroText: "Écris ce que tu veux voir, on génère la vidéo. Pour les créateurs, les étudiants et les entreprises.",
    heroCta: "Commencer — 3 vidéos offertes",
    loginTitle: "Connexion",
    loginEmail: "Ton e-mail",
    loginButton: "Recevoir mon lien de connexion",
    loginSent: "📩 Regarde ta boîte mail et clique sur le lien pour te connecter.",
    credits: "crédits",
    describe: "Décris ta vidéo (en français ou en anglais)",
    placeholder: "Ex : Coucher de soleil sur des collines, plan aérien lent, style cinéma",
    generate: "Générer la vidéo (1 crédit)",
    sending: "Envoi…",
    myVideos: "Mes vidéos",
    noVideos: "Aucune vidéo pour l'instant.",
    pending: "⏳ En cours de création…",
    failed: "❌ Échec — crédit rendu",
    download: "Télécharger",
    // erreurs
    errLogin: "Connecte-toi d'abord.",
    errShort: "Décris ta vidéo en au moins 10 caractères.",
    errLong: "Ta description est trop longue (1000 caractères max).",
    errBlocked: "Cette demande n'est pas autorisée.",
    errBusy: "Attends que tes vidéos en cours soient finies.",
    errCredits: "Pas assez de crédits.",
    errStart: "La génération n'a pas pu démarrer. Crédits rendus.",
    errServer: "Erreur serveur.",
  },
  en: {
    heroTitle: "Create videos with AI",
    heroText: "Write what you want to see, we generate the video. For creators, students and businesses.",
    heroCta: "Get started — 3 free videos",
    loginTitle: "Sign in",
    loginEmail: "Your email",
    loginButton: "Send me a sign-in link",
    loginSent: "📩 Check your inbox and click the link to sign in.",
    credits: "credits",
    describe: "Describe your video (in English or French)",
    placeholder: "E.g. Sunset over green hills, slow aerial shot, cinematic style",
    generate: "Generate video (1 credit)",
    sending: "Sending…",
    myVideos: "My videos",
    noVideos: "No videos yet.",
    pending: "⏳ Generating…",
    failed: "❌ Failed — credit refunded",
    download: "Download",
    errLogin: "Please sign in first.",
    errShort: "Describe your video in at least 10 characters.",
    errLong: "Your description is too long (1000 characters max).",
    errBlocked: "This request is not allowed.",
    errBusy: "Wait until your current videos are finished.",
    errCredits: "Not enough credits.",
    errStart: "Generation could not start. Credits refunded.",
    errServer: "Server error.",
  },
} satisfies Record<Lang, Record<string, string>>;

export type Dict = (typeof dict)["fr"];
