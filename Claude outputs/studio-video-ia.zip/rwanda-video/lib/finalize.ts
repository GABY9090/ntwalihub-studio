import { fal } from "@fal-ai/client";
import { supabaseAdmin } from "./supabase";

fal.config({ credentials: process.env.FAL_KEY });

type Admin = ReturnType<typeof supabaseAdmin>;
type PendingVideo = { id: string; user_id: string; credits_spent: number; fal_request_id: string | null; created_at: string };

// Vidéo réussie : on "réserve" la ligne (pending -> ready) pour ne la traiter qu'une fois,
// même si le webhook et la vérification arrivent en même temps.
export async function markReady(admin: Admin, video: PendingVideo, falUrl: string) {
  const { data: claimed } = await admin.from("videos")
    .update({ status: "ready", video_url: falUrl })
    .eq("id", video.id).eq("status", "pending")
    .select("id");
  if (!claimed?.length) return; // déjà traitée

  // Copier la vidéo dans notre stockage (les liens fal.ai ne sont pas permanents)
  try {
    const file = await fetch(falUrl);
    const bytes = new Uint8Array(await file.arrayBuffer());
    const path = `${video.user_id}/${video.id}.mp4`;
    const { error } = await admin.storage.from("videos")
      .upload(path, bytes, { contentType: "video/mp4", upsert: true });
    if (error) throw error;
    const { data } = admin.storage.from("videos").getPublicUrl(path);
    await admin.from("videos").update({ video_url: data.publicUrl }).eq("id", video.id);
  } catch (e) {
    console.error("⚠️ Copie vers Supabase Storage impossible, lien fal.ai conservé :", e);
  }
}

// Vidéo ratée : statut "failed" + remboursement (une seule fois)
export async function markFailed(admin: Admin, video: PendingVideo, reason: string) {
  const { data: claimed } = await admin.from("videos")
    .update({ status: "failed", error: reason.slice(0, 500) })
    .eq("id", video.id).eq("status", "pending")
    .select("id");
  if (!claimed?.length) return;
  await admin.rpc("add_credits", {
    p_user: video.user_id, p_amount: video.credits_spent,
    p_reason: "remboursement", p_reference: video.id,
  });
}

// Demande à fal.ai où en est une vidéo (utilisé sans webhook, ex : en local)
export async function checkWithFal(admin: Admin, video: PendingVideo) {
  if (!video.fal_request_id) return;
  const model = process.env.FAL_MODEL!;

  // Sécurité : au-delà de 20 minutes, on abandonne et on rembourse
  if (Date.now() - new Date(video.created_at).getTime() > 20 * 60 * 1000) {
    return markFailed(admin, video, "délai dépassé");
  }

  try {
    const status = await fal.queue.status(model, { requestId: video.fal_request_id });
    if (status.status !== "COMPLETED") return; // encore en cours
    const result = await fal.queue.result(model, { requestId: video.fal_request_id });
    const url = (result.data as { video?: { url?: string } })?.video?.url;
    if (url) await markReady(admin, video, url);
    else await markFailed(admin, video, "pas de vidéo dans la réponse");
  } catch (e) {
    // fal.ai renvoie une erreur quand la génération a échoué
    const body = JSON.stringify((e as { body?: unknown })?.body ?? String(e));
    console.error("❌ fal.ai (vérification) :", body);
    if ((e as { status?: number })?.status && (e as { status: number }).status < 500) {
      await markFailed(admin, video, body);
    }
  }
}
