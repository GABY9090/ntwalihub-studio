import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase";
import { getDict } from "@/lib/lang";
import Studio from "@/components/Studio";

export default async function StudioPage() {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { t } = await getDict();
  return <Studio email={user.email ?? ""} t={t} />;
}
