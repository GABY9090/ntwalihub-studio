import type { Metadata, Viewport } from "next";
import { getLang } from "@/lib/lang";
import LangSwitch from "@/components/LangSwitch";
import "./globals.css";

export const metadata: Metadata = {
  title: "Studio IA",
  description: "AI video generator — Générateur de vidéos IA",
  manifest: "/manifest.json",
  appleWebApp: { capable: true, title: "Studio IA", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = { themeColor: "#0f172a", width: "device-width", initialScale: 1 };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const lang = await getLang();
  return (
    <html lang={lang}>
      <body>
        <LangSwitch lang={lang} />
        {children}
      </body>
    </html>
  );
}
